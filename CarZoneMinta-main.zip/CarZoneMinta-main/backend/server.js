const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();

const path = require('path');
app.use(express.static(path.join(__dirname, '..', 'backend')));

app.use(bodyParser.urlencoded({ extended: true }));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'carzone'
});


app.get('/kartya', (req, res) => {
    connection.query('SELECT * FROM kartya', (err, results) => {
        if (err) {
            return res.status(500).send('Hiba történt: ' + err);
        }

        res.json(results);
    });
});

app.listen(3000, () => {
    console.log('Szerver fut a http://localhost:3000 címen');
});




