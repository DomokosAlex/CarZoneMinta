async function fetchProducts() {
            try {
                const response = await fetch('/kartya');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const kartyak = await response.json();
                const sorok = document.getElementById("sor");

                kartyak.forEach(e => {
                    const col = document.createElement("div");
                    col.className = "col-lg-4 mb-4"; 

                    const card = document.createElement("div");
                    card.className = "card";  

                    card.innerHTML = `
  <img class="card-img-top" src="${"forrasok/" + e.kep + ".jpg"}" alt="img">
  <div class="card-body">
    <h5 class="card-title">${e.cim}</h5>
    <a href="#" class="btn btn-dark">Részletek</a>
  </div>`;

                    col.appendChild(card);
                    sorok.appendChild(col);
                });



            } catch (error) {
                console.error('Fetch error:', error);
            }
        }

window.addEventListener("load", fetchProducts);